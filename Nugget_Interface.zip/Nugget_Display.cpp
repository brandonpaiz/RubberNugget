#include "Nugget_Display.h"
// #include "SH1106Wire.h"

Nugget_Display::Nugget_Display() {

}

/* static function to initialize Nugget w/ default parameters:
 * I2C SH1106 @ 0x3C, read display orientation from IO
 */
 
void Nugget_Display::init() {

}
