#pragma once

#include "Arduino.h"

class Nugget_Display {

    public:
        Nugget_Display();
        static void init();
        
    private:
};